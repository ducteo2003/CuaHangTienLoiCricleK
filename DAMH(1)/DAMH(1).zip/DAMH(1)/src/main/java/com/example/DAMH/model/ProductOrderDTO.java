package com.example.DAMH.model;

public class ProductOrderDTO {
    private int barcode;
    private int soLuong;

    // Getters and Setters

    public int getBarcode() {
        return barcode;
    }

    public void setBarcode(int barcode) {
        this.barcode = barcode;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }
}
