package com.example.DAMH.repository;

import com.example.DAMH.model.DONDATHANG;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DONDATHANGRepository extends JpaRepository<DONDATHANG, Integer> {
}
