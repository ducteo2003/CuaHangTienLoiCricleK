package com.example.DAMH.repository;

import com.example.DAMH.model.KHO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KHORepository extends JpaRepository<KHO, Integer> {
}