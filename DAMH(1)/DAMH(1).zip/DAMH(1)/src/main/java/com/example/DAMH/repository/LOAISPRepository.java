package com.example.DAMH.repository;

import com.example.DAMH.model.LOAISP;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LOAISPRepository extends JpaRepository<LOAISP, Integer> {
}
