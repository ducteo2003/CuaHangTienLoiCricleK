package com.example.DAMH.repository;

import com.example.DAMH.model.LUUKHO;
import org.springframework.data.jpa.repository.JpaRepository;


import com.example.DAMH.model.LUUKHO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LUUKHORepository extends JpaRepository<LUUKHO,Integer > {
}