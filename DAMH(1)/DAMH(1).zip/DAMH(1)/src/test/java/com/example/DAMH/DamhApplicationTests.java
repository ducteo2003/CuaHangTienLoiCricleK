package com.example.DAMH;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DamhApplicationTests {

	@Test
	void contextLoads() {
	}

}
